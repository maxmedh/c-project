#include <iostream>
#include "Reward.h"

Reward::Reward(){};
Reward::Reward(int rubi) :rubi(rubi) {};


